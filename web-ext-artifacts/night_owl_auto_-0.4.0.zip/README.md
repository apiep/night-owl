# Night Owl

The ultimate dark and white themes for Firefox
![screenshot](https://i.imgur.com/qmaYEBE.png)
![screenshot](https://i.imgur.com/4ZVC9y9.png)

![screenshot](https://i.imgur.com/dDKmNEf.png)
![screenshot](https://i.imgur.com/VcNs6Vz.png)

![screenshot](https://i.imgur.com/JqtlZOy.jpg)
![screenshot](https://i.imgur.com/ZqISacp.png)

> Icons are created by [Oksana Latysheva](https://thenounproject.com/latyshevaoksana/uploads/?i=759872) from the [Noun Project](https://thenounproject.com)
